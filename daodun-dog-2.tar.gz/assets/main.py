import pygame
import random
import math
import asyncio

pygame.init()

WIDTH = 900
HEIGHT = 600

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("DaoDun-Dog Game")

clock = pygame.time.Clock()
font = pygame.font.SysFont("Arial", 30)
big_font = pygame.font.SysFont("Arial", 90)

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (220, 80, 80)
GREEN = (100, 220, 100)
YELLOW = (255, 220, 0)
BLUE = (80, 180, 255)
BROWN = (120, 70, 20)

player_size = 90
player_x = WIDTH // 2
player_y = HEIGHT - 100
player_speed = 7

bullets = []
bullet_speed = 10

last_shot_time = 0
shot_cooldown = 700

poops = []
poop_speed = 7

enemies = []
enemy_speed = 4
spawn_timer = 0

score = 0

player_hp = 3
max_hp = 3

running = True
game_over = False
game_started = False


damage_flash = 0
screen_shake = 0


death_fade = 0
death_text_y = -100


shielding = False


try:
    background_img = pygame.image.load("street.png")
    background_img = pygame.transform.scale(background_img, (WIDTH, HEIGHT))
except:
    background_img = None

try:
    start_bg = pygame.image.load("start.png")
    start_bg = pygame.transform.scale(start_bg, (WIDTH, HEIGHT))
except:
    start_bg = None

try:
    hit_sound = pygame.mixer.Sound("hit.ogg")
except:
    hit_sound = None

try:
    poop_hit_sound = pygame.mixer.Sound("shit.ogg")
except:
    poop_hit_sound = None

try:
    dog_img = pygame.image.load("dog.png")
    dog_img = pygame.transform.scale(dog_img, (120, 120))
except:
    dog_img = None

try:
    muscle_enemy_img = pygame.image.load("muscle.png")
    muscle_enemy_img = pygame.transform.scale(muscle_enemy_img, (80, 80))
except:
    muscle_enemy_img = None

try:
    normal_enemy_img = pygame.image.load("normal.png")
    normal_enemy_img = pygame.transform.scale(normal_enemy_img, (60, 60))
except:
    normal_enemy_img = None

try:
    bullet_img = pygame.image.load("knife.png")
    bullet_img = pygame.transform.scale(bullet_img, (50, 50))
except:
    bullet_img = None

try:
    poop_img = pygame.image.load("poop.png")
    poop_img = pygame.transform.scale(poop_img, (45, 45))
except:
    poop_img = None


async def main():

    global running
    global bullets
    global enemies
    global poops
    global score
    global player_hp
    global player_x
    global player_y
    global game_over
    global spawn_timer
    global damage_flash
    global screen_shake
    global death_fade
    global death_text_y
    global shielding
    global last_shot_time
    global game_started

    while running:

        if not game_started:

            if start_bg:
                screen.blit(start_bg, (0, 0))
            else:
                screen.fill(WHITE)

            title_text = big_font.render(
                "DAO DUN DOG",
                True,
                BLACK
            )

            start_text = font.render(
                "Press SPACE to Start",
                True,
                BLACK
            )

            move_text = font.render(
                "WASD = MOVE",
                True,
                BLACK
            )

            shield_text = font.render(
                "M = SHIELD",
                True,
                BLACK
            )

            shoot_text = font.render(
                "SPACE = SHOOT",
                True,
                BLACK
            )

            screen.blit(title_text, (WIDTH // 2 - 260, 120))

            screen.blit(start_text, (WIDTH // 2 - 170, 240))

            screen.blit(move_text, (WIDTH // 2 - 120, 320))
            screen.blit(shield_text, (WIDTH // 2 - 120, 360))
            screen.blit(shoot_text, (WIDTH // 2 - 120, 400))

            for event in pygame.event.get():

                if event.type == pygame.QUIT:
                    running = False

                if event.type == pygame.KEYDOWN:

                    if event.key == pygame.K_SPACE:
                        bullets = []
                        enemies = []
                        poops = []

                        score = 0
                        player_hp = max_hp

                        player_x = WIDTH // 2
                        player_y = HEIGHT - 100

                        damage_flash = 0
                        screen_shake = 0

                        death_fade = 0
                        death_text_y = -100

                        spawn_timer = 0

                        game_over = False
                        game_started = True
                        
                        break

            pygame.display.update()
            await asyncio.sleep(0)
            continue

        clock.tick(120)


        shake_x = 0
        shake_y = 0

        if screen_shake > 0:
            shake_x = random.randint(-8, 8)
            shake_y = random.randint(-8, 8)
            screen_shake -= 1


        if background_img:
            screen.blit(background_img, (shake_x, shake_y))
        else:
            screen.fill(WHITE)


        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:

               
                if event.key == pygame.K_r and game_over:

                    bullets = []
                    enemies = []
                    poops = []

                    score = 0
                    player_hp = max_hp

                    player_x = WIDTH // 2
                    player_y = HEIGHT - 100

                    damage_flash = 0
                    screen_shake = 0

                    death_fade = 0
                    death_text_y = -100

                    game_over = False

              
                if event.key == pygame.K_SPACE and not game_over and not shielding:

                    current_time = pygame.time.get_ticks()

                 
                    if current_time - last_shot_time >= shot_cooldown:

                        bullet = pygame.Rect(
                            player_x + player_size // 2 - 12,
                            player_y,
                            24,
                            40
                        )

                        bullets.append(bullet)

                        last_shot_time = current_time

                if event.key == pygame.K_ESCAPE:

                    bullets.clear()
                    enemies.clear()
                    poops.clear()

                    score = 0
                    player_hp = max_hp

                    player_x = WIDTH // 2
                    player_y = HEIGHT - 100

                    damage_flash = 0
                    screen_shake = 0

                    death_fade = 0
                    death_text_y = -100

                    spawn_timer = 0

                    game_over = False
                    game_started = False



                


        if game_over:

            fade_surface = pygame.Surface((WIDTH, HEIGHT))
            fade_surface.fill(BLACK)

            if death_fade < 255:
                death_fade += 4

            fade_surface.set_alpha(death_fade)

            screen.blit(fade_surface, (0, 0))

            if death_text_y < HEIGHT // 2 - 80:
                death_text_y += 6

            over_text = big_font.render("GAME OVER", True, RED)
            score_text = font.render(f"Score : {score}", True, WHITE)            
            restart_text = font.render("Press R to Restart", True, WHITE)          

            screen.blit(
                over_text,
                (WIDTH // 2 - 250, death_text_y)
            )

            screen.blit(
                score_text,
                (WIDTH // 2 - 70, death_text_y + 120)
            )

            screen.blit(
                restart_text,
                (WIDTH // 2 - 150, death_text_y + 180)
            )

            pygame.display.update()
            await asyncio.sleep(0)
            continue


        keys = pygame.key.get_pressed()

        
        shielding = keys[pygame.K_m]

    
        if not shielding:

            if keys[pygame.K_a] and player_x > 0:
                player_x -= player_speed

            if keys[pygame.K_d] and player_x < WIDTH - player_size:
                player_x += player_speed

            if keys[pygame.K_w] and player_y > 0:
                player_y -= player_speed

            if keys[pygame.K_s] and player_y < HEIGHT - player_size:
                player_y += player_speed

        player_rect = pygame.Rect(
            player_x,
            player_y,
            player_size,
            player_size
        )


        if dog_img:

            screen.blit(
                dog_img,
                (
                    player_x - 10 + shake_x,
                    player_y - 10 + shake_y
                )
            )

        else:
            pygame.draw.rect(screen, WHITE, player_rect)


        if shielding:

            shield_radius = 70 + int(math.sin(pygame.time.get_ticks() * 0.01) * 5)

            pygame.draw.circle(
                screen,
                BLUE,
                (
                    player_x + player_size // 2 + shake_x,
                    player_y + player_size // 2 + shake_y
                ),
                shield_radius,
                6
            )

            pygame.draw.circle(
                screen,
                WHITE,
                (
                    player_x + player_size // 2 + shake_x,
                    player_y + player_size // 2 + shake_y
                ),
                shield_radius - 10,
                2
            )


        for bullet in bullets[:]:

            bullet.y -= bullet_speed

            if bullet_img:

                screen.blit(
                    bullet_img,
                    (
                        bullet.x - 10 + shake_x,
                        bullet.y - 10 + shake_y
                    )
                )

            else:
                pygame.draw.rect(screen, YELLOW, bullet)

            if bullet.y < 0:
                bullets.remove(bullet)


        spawn_timer += 1

        if spawn_timer > 40:

            enemy_x = random.randint(0, WIDTH - 60)

            if random.random() < 0.2:

                enemy = {
                    "rect": pygame.Rect(enemy_x, -60, 80, 80),
                    "hp": 2,
                    "type": "muscle",
                    "dx": random.choice([-3, 3]),
                    "poop_timer": 89
                }

            else:

                enemy = {
                    "rect": pygame.Rect(enemy_x, -60, 60, 60),
                    "hp": 1,
                    "type": "normal",
                    "dx": 0
                }

            enemies.append(enemy)
            spawn_timer = 0


        for enemy in enemies[:]:

            rect = enemy["rect"]

            if enemy["type"] == "muscle":

                rect.y += enemy_speed
                rect.x += enemy["dx"]

                if rect.x <= 0 or rect.x >= WIDTH - rect.width:
                    enemy["dx"] *= -1

                enemy["poop_timer"] += 1

                if enemy["poop_timer"] > 90:

                    poop = {
                        "rect": pygame.Rect(
                            rect.x + 20,
                            rect.y + 60,
                            35,
                            35
                        ),
                        "explode": False,
                        "radius": 0,
                        "timer": 0
                    }

                    poops.append(poop)
                    enemy["poop_timer"] = 0

                pygame.draw.rect(
                    screen,
                    RED,
                    (
                        rect.x + shake_x,
                        rect.y - 12 + shake_y,
                        80,
                        8
                    )
                )

                pygame.draw.rect(
                    screen,
                    GREEN,
                    (
                        rect.x + shake_x,
                        rect.y - 12 + shake_y,
                        40 * enemy["hp"],
                        8
                    )
                )

                if muscle_enemy_img:

                    screen.blit(
                        muscle_enemy_img,
                        (
                            rect.x - 5 + shake_x,
                            rect.y - 5 + shake_y
                        )
                    )

                else:
                    pygame.draw.rect(screen, RED, rect)

            else:

                rect.y += enemy_speed

                if normal_enemy_img:

                    screen.blit(
                        normal_enemy_img,
                        (
                            rect.x - 5 + shake_x,
                            rect.y - 5 + shake_y
                        )
                    )

                else:
                    pygame.draw.rect(screen, RED, rect)

            if player_rect.colliderect(rect):

                player_hp -= 1

                damage_flash = 12
                screen_shake = 18

                enemies.remove(enemy)

                if player_hp <= 0:
                    game_over = True

            if rect.y > HEIGHT:

                if enemy in enemies:
                    enemies.remove(enemy)


        for poop in poops[:]:

            rect = poop["rect"]

            if not poop["explode"]:

                rect.y += poop_speed

                if poop_img:

                    screen.blit(
                        poop_img,
                        (
                            rect.x + shake_x,
                            rect.y + shake_y
                        )
                    )

                else:
                    pygame.draw.rect(screen, BROWN, rect)

           
                if shielding:

                    shield_rect = pygame.Rect(
                        player_x - 20,
                        player_y - 20,
                        player_size + 40,
                        player_size + 40
                    )

                    if rect.colliderect(shield_rect):

                        score += 1
                        screen_shake = 10

                        if poop in poops:
                            poops.remove(poop)

                        continue

            
                if rect.colliderect(player_rect):

                    poop["explode"] = True
                    poop["radius"] = 20

                    if poop_hit_sound:
                        poop_hit_sound.play()

                    player_hp -= 1

                    damage_flash = 12
                    screen_shake = 18

                    if player_hp <= 0:
                        game_over = True

             
                elif rect.y > HEIGHT - 50:

                    poop["explode"] = True
                    poop["radius"] = 20

            else:

                poop["radius"] += 8
                poop["timer"] += 1

                pygame.draw.circle(
                    screen,
                    BROWN,
                    (
                        rect.centerx + shake_x,
                        rect.centery + shake_y
                    ),
                    poop["radius"]
                )

                pygame.draw.circle(
                    screen,
                    YELLOW,
                    (
                        rect.centerx + shake_x,
                        rect.centery + shake_y
                    ),
                    poop["radius"] // 2
                )

                explosion_rect = pygame.Rect(
                    rect.centerx - poop["radius"],
                    rect.centery - poop["radius"],
                    poop["radius"] * 2,
                    poop["radius"] * 2
                )

                if explosion_rect.colliderect(player_rect):

                    if poop["timer"] == 1:

                        player_hp -= 1

                        damage_flash = 12
                        screen_shake = 18

                        if player_hp <= 0:
                            game_over = True

                if poop["timer"] > 10:

                    if poop in poops:
                        poops.remove(poop)


        for bullet in bullets[:]:

            for enemy in enemies[:]:

                rect = enemy["rect"]

                if bullet.colliderect(rect):

                    if bullet in bullets:
                        bullets.remove(bullet)

                    enemy["hp"] -= 1

                    if enemy["hp"] <= 0:

                        if hit_sound:
                            hit_sound.play()

                        if enemy in enemies:
                            enemies.remove(enemy)


                        if enemy["type"] == "muscle":
                            score += 2
                        else:
                            score += 1

                    break


        score_text = font.render(
            f"Score: {score}",
            True,
            WHITE
        )

        esc_text = font.render(
            "ESC = EXIT",
            True,
            WHITE
        )

        screen.blit(
            score_text,
            (20 + shake_x, 20 + shake_y)
        )
        
        screen.blit(
            esc_text,
            (WIDTH - 220 + shake_x, 20 + shake_y)
        )
        

        for i in range(player_hp):

            pygame.draw.circle(
                screen,
                RED,
                (35 + i * 40 + shake_x, 70 + shake_y),
                12
            )

            pygame.draw.circle(
                screen,
                RED,
                (50 + i * 40 + shake_x, 70 + shake_y),
                12
            )

            pygame.draw.polygon(
                screen,
                RED,
                [
                    (23 + i * 40 + shake_x, 75 + shake_y),
                    (62 + i * 40 + shake_x, 75 + shake_y),
                    (42 + i * 40 + shake_x, 100 + shake_y)
                ]
            )


        if damage_flash > 0:

            flash_surface = pygame.Surface((WIDTH, HEIGHT))

            flash_surface.set_alpha(80)
            flash_surface.fill((255, 0, 0))

            screen.blit(flash_surface, (0, 0))

            damage_flash -= 1

        pygame.display.update()
        
        await asyncio.sleep(0)

    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())
